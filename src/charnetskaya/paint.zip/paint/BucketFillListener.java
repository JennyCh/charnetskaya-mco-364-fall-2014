package charnetskaya.paint;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.util.LinkedList;
import java.util.Queue;

public class BucketFillListener implements DrawListenerInterface {

	private final Queue<Point> stack;
	private final Canvas canvas;

	public BucketFillListener(Canvas canvas) {
		// TODO Auto-generated constructor stub
		this.stack = new LinkedList<Point>();
		// this.initialPoint = new Point();
		this.canvas = canvas;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		final BufferedImage img = canvas.getImage();
		final Graphics2D g2 = (Graphics2D) img.getGraphics();
		g2.setColor(Color.red);
		final int x = e.getX();
		final int y = e.getY();

		int y1;
		boolean spanLeft, spanRight;

		stack.add(new Point(x, y));

		while (!stack.isEmpty()) {
			final Point p = stack.poll();
			final int currentX = (int) p.getX();
			final int currentY = (int) p.getY();

			y1 = currentY;
			while (y1 >= 0 && Color.white.equals(new Color(img.getRGB(currentX, y1)))) {
				y1--;
			}
			y1++;

			spanLeft = spanRight = false;
			final int width = img.getWidth();
			final int height = img.getHeight();

			while (y1 < height && Color.white.equals(new Color(img.getRGB(currentX, y1)))) {
				g2.drawLine(currentX, y1, currentX, y1);

				if (!spanLeft && currentX > 0 && Color.white.equals(new Color(img.getRGB(currentX - 1, y1)))) {
					stack.add(new Point(currentX - 1, y1));
					spanLeft = true;
				} else if (spanLeft && currentX > 0 && !Color.white.equals(new Color(img.getRGB(currentX - 1, y1)))) {
					spanLeft = false;
				}

				if (!spanRight && currentX < width - 1 && Color.white.equals(new Color(img.getRGB(currentX + 1, y1)))) {
					stack.add(new Point(currentX + 1, y1));
					spanRight = true;
				} else if (spanRight && currentX < width - 1
						&& !Color.white.equals(new Color(img.getRGB(currentX + 1, y1)))) {
					spanRight = false;
				}
				y1++;
			}
		}
		canvas.repaint();
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseDragged(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void draw(Graphics2D g2) {
		// TODO Auto-generated method stub

	}

	@Override
	public void preview(Graphics2D g2) {
		// TODO Auto-generated method stub

	}

}
