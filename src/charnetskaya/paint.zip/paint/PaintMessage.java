package charnetskaya.paint;

import java.awt.Graphics2D;

public interface PaintMessage {

	// runs what the message should be doing
	public void apply(Graphics2D g2);
}
