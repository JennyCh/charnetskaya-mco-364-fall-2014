package charnetskaya.paint;

public enum ShapeType {
	RECT, OVAL
}
