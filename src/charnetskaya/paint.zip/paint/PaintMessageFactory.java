package charnetskaya.paint;

public class PaintMessageFactory {

	public String getMessage(String paintMessage) {
		return paintMessage;
	}
}
